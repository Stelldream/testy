export default function Loader() {
  return (
    <div className='cart section bd-container empty'>
      <i className='bx bx-loader-circle bx-spin bx-lg'></i>
    </div>
  )
}
